Emilio Wu, A00768079, Set A, 5 February 2014

This assignment is 100% complete.


------------------------
Question one (Stickman) status:

Complete
[explanation if not complete, what is working/not working]

------------------------
Question two (SecondsConvert) status:

Complete
[explanation if not complete, what is working/not working]

------------------------
Question three (TempConvert) status:

Complete
[explanation if not complete, what is working/not working]

------------------------
Question four (Cylinder) status:

Complete
[explanation if not complete, what is working/not working]

------------------------
Question five (BusinessCard) status:

Complete
[explanation if not complete, what is working/not working]
